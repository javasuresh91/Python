import datetime
currentTime = datetime.datetime.now() 
print (currentTime)
print (currentTime.hour) 
print (currentTime.minute)
print (currentTime.second)
datetime.datetime.strftime(currentTime,'%H:%M')
