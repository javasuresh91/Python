import os,string



for dir in os.environ['PYTHONPATH'].split(os.pathsep):
   print(dir)


























'''
print(os.environ.keys())

print(os.environ['TEMP'])

os.environ['TEMP'] = r'c:\temp'
print(os.environ['TEMP'])
'''
