class Parent:        # define parent class
    def __init__(self):
       self.a=100
    def disp(self):
        print(self.a)
c=Parent()
c.disp()
 

f=open("obj.txt","wb")
import marshal
marshal.dump(c,f)
f.close()

f=open("obj.txt","rb")
d = marshal.load(f)
type(d)
d.disp()
