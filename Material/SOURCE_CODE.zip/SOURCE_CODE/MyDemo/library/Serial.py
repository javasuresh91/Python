'''
Created on Mar 4, 2016

@author: DD0056362

'''
class X:
    def __init__(self):
        self.name="dd"
        self.age=30

    def display(self):
        print("display method")
        
c=X() #serialize this object for future


import pickle

'''
f=open("serial_file","wb")
p=pickle.Pickler(f) 
p.dump(c) #serialized
f.close()  

f=open("serial_file","rb")
u= pickle.Unpickler(f) # file is an open file
obj = u.load()
print(obj.name) #dd
print(obj.age) #30
obj.display()
'''










    
        
