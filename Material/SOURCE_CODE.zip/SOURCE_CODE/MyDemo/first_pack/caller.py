'''
Created on Mar 17, 2016

@author: DD0056362
'''
import first_pack.m1 as m
m.fun()


