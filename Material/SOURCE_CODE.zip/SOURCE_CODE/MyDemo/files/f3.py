

# Open a file
try:
    fo = open("d:/foo.txt", "rb+")
    str1 = fo.read(5);
except IOError:
    print("File doesnot exist")
else:
    print("Read String is : ", str1)
# Check current position
    position = fo.tell();
    print("Current file position : ", position)

# Reposition pointer at the beginning once again
    fo.seek(-2, 1)

    str1 = fo.read(5);
    print("Again read String is : ", str1)
# Close opend file
    fo.close()
print("This is after handling exception")