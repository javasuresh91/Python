'''
Created on May 18, 2016

@author: DD0056362'''

'''
fr=open("foo1.txt","r")
str1=fr.read()
print(str1)
'''

'''
fr=open("foo1.txt","r")
list1=fr.readlines()
print(list1)
'''

'''
#usage of split
for rec in list1:
    x=rec.split(':')
    print(x[0])
    print(x[1])
    print(x[2])

'''
















