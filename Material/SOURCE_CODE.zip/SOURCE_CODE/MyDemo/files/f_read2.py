'''
Created on Mar 17, 2016

@author: DD0056362
'''
fo = open("foo.txt", "r")
l= [ x for x in open("foo.txt","r").readlines() ]
print(l)



'''
s=fo.read(15); # reads into a string
print(s)


l=fo.readlines() # reads into a list
# This is good for record based data
print(l)
print(l[1])

'''


'''
print(fo.tell())
fo.seek(0,0)
print(fo.tell())
'''



'''
print(l[-1])
#print(l)
fo.seek(0,0)

p=fo.read(10)
print(p)
print(fo.tell())
'''
fo.close()
