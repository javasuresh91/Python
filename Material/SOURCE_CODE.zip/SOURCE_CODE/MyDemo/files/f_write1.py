# Open a file

fo = open("score.txt","a")
'''
for i in range(2):
    
    id=input('enter ur eid')
    name=input('enter ur name')
    score=input('enter ur score')


    str=id+':'+name+':'+score+'\n'
    fo.write(str) #writing a string
    
fo.close()
'''


scores=['1:amit:90\n','2:anil:99\n']
fo.writelines(scores) # takes list as argument

# Close opened file
fo.close()

print(fo.closed)



