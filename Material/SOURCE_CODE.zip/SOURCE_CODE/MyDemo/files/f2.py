# Open a file
fo = open("foo.txt", "r+")
print(fo.readlines())
#print(fo.read())
#print(fo.readlines())

for i in range(1,6):
    
    fo.write(str(i)+"\n")

i=fo.read()
print(i)
l=i.split(" ")
print(l[0])
'''
s=0
for line in fo:
    l=line.split(" ")
    s+=int(line)
    print(line, end=' ')
print(s)

'''

#Close opend file
fo.close()

