import xlrd
workbook = xlrd.open_workbook("Book.xlsx")
worksheet = workbook.sheet_by_name("Users")

print(worksheet.cell_value(1,1))
