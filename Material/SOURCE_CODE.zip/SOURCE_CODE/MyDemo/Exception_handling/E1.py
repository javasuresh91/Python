'''
Created on Mar 3, 2016

@author: DD0056362
'''


try:
    f = open("myfile1.txt") #1
    s = f.read() #2
    i = int(s.strip())   #3
    
except  FileNotFoundError as f:
    print("It is an IO error ")
    print(f)     #4

except ValueError:
    print("cannot convert from character to int") #6
except:
    print("Any other exception")  #7
    
else: #executes only if there is no exception
    print("No exception smile :-)")    #8

print("outside everything") #9
print("other lines of code") #10


