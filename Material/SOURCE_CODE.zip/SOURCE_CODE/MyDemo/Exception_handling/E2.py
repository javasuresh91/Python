

print ("reading from file")
try:
    fh=open("myfileabc") #exception would be raised here - alternative path exists ?
    str=fh.read()
    print(str)
except IOError:
    print('Pls enter a valid file name')

print('done')    


















'''
    print("abcd")
    try:
        fh = open("myf")
    except IOError:
        print("handled the IO prob")
    finally:
        print ("Going to close the file")
    print("after finally")    

print("out")
'''



