class B(Exception):
            pass
    
class C(B):
        pass
class D(C):
        pass

for c in [B, C, D]:
        try:
            
            raise(c) # raise the exceptions B
            pass
               
   
        except D:
            print("D")
        except C:
            print("C")
        except B:
            print("B")
        except:
            print("some other exception")    

        print("Handled the current exc raised")

      

