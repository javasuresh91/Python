import pack1.calc as c
c.add(3,2)



