def add(a,b):
    print(a+b)

def sub(a,b):
    print(a-b)