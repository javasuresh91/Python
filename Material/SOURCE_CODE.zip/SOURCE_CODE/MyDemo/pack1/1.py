import math
print(math.sqrt(9))
 
import math as m
print(m.pow(2,3),m.ceil(12.1))
 
 
from math import pow,sqrt # this import will overwrite the above one
print(pow(2,3))
print(sqrt(9))
#print(floor(10.9))

def pow(a,b):
    print("My power function")
pow(1,2)   
from math import *
print(pow(2,3))
print(sqrt(9))
print(floor(10.9))
math.sqrt(9)


