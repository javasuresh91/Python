#0,1,1,2,3,5,8,13,

f1, f2 = -1,1
n=int(input("Enter n"))
while (f2 < n):
    f1, f2 = f2, f1+f2
    print(f2,end=",")
else:
     print("\nEnd of Fibonacci Series")
