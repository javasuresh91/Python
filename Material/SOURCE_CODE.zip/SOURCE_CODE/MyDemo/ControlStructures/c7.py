for i in range(10):
    if i==5:
        break
    print(i)

for letter in 'Python':     # First Example
    if letter == 'h':
        continue
    print( 'Current Letter :', letter)

'''
for num in range(2, 10):
    if num % 2 == 0:
        print("Found an even number", num)
        continue
    print("Odd number", num
    
 '''   