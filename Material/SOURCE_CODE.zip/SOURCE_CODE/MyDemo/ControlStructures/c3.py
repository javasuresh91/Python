
print("Demo 1 ")
count = 0

while (count < 9):
    if count%2==0:
        print('The count is:', count)
    count += 1



print("Demo 2 ")
count = 0
while count < 5:
    print( count, " is  less than 5")
    count = count + 1
    
else:
    print( count, " is not less than 5")


