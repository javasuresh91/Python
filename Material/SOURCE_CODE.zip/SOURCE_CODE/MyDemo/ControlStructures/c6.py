for letter in 'Python':
    if letter == 'h':
        pass # do nothing for now - but keep probability open for future coding
        print('This is pass block')
        print('Current Letter :', letter)
