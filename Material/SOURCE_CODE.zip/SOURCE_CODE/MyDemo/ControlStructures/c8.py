while True:
    pass