
a = ['cat', 'window', 10, 12.3]
for x in a:
    print(x)

    

a="Python"
for x in a:
    print(x)


for i in range(1,10,2):
    print(i)




fruits= {'apple': 'red', 'mango': 'yellow'}
for k, v in fruits.items():
    print(k, v,)


questions = ['name', 'Class', 'Score']
answers = ['Sana', '2', '99']
for q, a in zip(questions, answers):
    print('What is your %s? It is %s.'%(q, a))


for i in reversed(range(1, 10, 2)):
    print(i)


basket = ['its mine', 'Orange', 'Orrange', 'pear', 'orange', 'banana','1','2','3','400']
for f in sorted(basket):
        print(f)



