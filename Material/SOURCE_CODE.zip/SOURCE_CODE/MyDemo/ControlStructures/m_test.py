import module.m1
module.m1.fun()
