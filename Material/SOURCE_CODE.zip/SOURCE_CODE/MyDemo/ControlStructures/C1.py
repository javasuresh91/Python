x = int(input("Please enter an integer: "))

if x < 0:          
        print('Negative no \n Inside if')
        print('x = ',x)
    
else:
        print('Positive no')
    
print("Bye")


