

print("From my_mod inside pack")
