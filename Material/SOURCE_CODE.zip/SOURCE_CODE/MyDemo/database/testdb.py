from mysql.connector import connect,Error, errorcode
# Open database connection 
try:
    conn = connect (host = "localhost",
                           user = "root",
                           passwd = "root",
                           db = "test")
except Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("Something is wrong with your user name or password")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("Database does not exists")
    else:
        print(err)
else:
    print("success")
# prepare a cursor object using cursor() method 
cursor = conn.cursor() 

# execute SQL query using execute() method. 
cursor.execute("SELECT VERSION()") 

# Fetch a single row using fetchone() method. 
data = cursor.fetchone() 

print("Database version : %s " % data) # disconnect from server 
conn.close()
