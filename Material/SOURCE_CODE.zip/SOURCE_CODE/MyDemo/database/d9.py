'''
Created on May 20, 2016

@author: DD0056362
'''
'''
get the PyMySQL.tar from PyPi 
Untar and copy it in "C:\Python34\Lib\site-packages"
Run the setup.py file
Add the path "C:\Python34\Lib\site-packages\PyMySQL-0.7.2" in PYTHONPATH
'''
import pymysql.cursors

# Connect to the database
conn = pymysql.connect(host='localhost',
                             user='root',
                             password='password',
                             db='test',
                             cursorclass=pymysql.cursors.DictCursor)

try:
    with conn.cursor() as cursor:
        
        '''
        cursor.execute ("select version()")
        row = cursor.fetchone ()
        print( "server version:", row)
        
        
        #select
        cursor.execute ("SELECT eid, name FROM employee")
        rows = cursor.fetchall()
        for row in rows:
             print (row)
        print ("Number of rows returned: %d" % cursor.rowcount)
       
        
        
        #DDL
        
        cursor.execute ("DROP TABLE IF EXISTS animal")      
        
        
        cursor.execute ("""
       CREATE TABLE animal
       (
         name     CHAR(40),
         category CHAR(40)
       )
     """)
       
        
        
        #insert
        cursor.execute (" INSERT INTO animal (name, category) VALUES ('python', 'reptile'),('frog', 'amphibian'),('shark', 'fish'),('penguin', 'mammal')")
        print ("Number of rows inserted: %d" % cursor.rowcount)
        conn.commit()
        
        '''
        #update
        cursor.execute (" UPDATE animal SET name = 'snake' WHERE name = 'python' ")
        print ("Number of rows updated: %d" % cursor.rowcount)
        conn.commit()       
        

finally:
    conn.close()
