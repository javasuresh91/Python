'''
Created on Mar 3, 2016

@author: DD0056362
'''
def fun():
    print("Python is fun in m2")