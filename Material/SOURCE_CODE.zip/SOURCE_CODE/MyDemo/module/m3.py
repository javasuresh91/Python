'''
Created on Mar 3, 2016
@author: DD0056362

'''
#you have to add the parent directory of the module in the PYTHONPATH of eclipse#
'''
import m1 as x
import math
print(math.pow(2, 3))
m1.pow(3,2)
'''

#BUT

from math import pow
from m1 import pow
#the latest import will occur
pow(2,3)
print(pow(3,4))
