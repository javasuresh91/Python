'''
Created on Mar 3, 2016

@author: DD0056362
sys.path.append("parent directory of module") --> temporary .. once shell is restarted it vanishes
Set pythonpath from environment variable to include Parent directory
See as os.environ['PYTHONPATH'] --> permanent
'''
def fun():
    print("Python is fun in m1 **")
    
    
def abs(x):
    print("This is abs from m1")   
    
def pow(x,y):
    print("pow from m1")   
    
    
    
    
    
    
    
    
    
    
    
      
    
'''    
if __name__=="__main__": # this cond is true when a module is run directly#
    import sys
    fun()
    abs(int(sys.argv[1]))
'''