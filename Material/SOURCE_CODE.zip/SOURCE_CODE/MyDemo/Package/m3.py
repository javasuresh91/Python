def fun():
        print('abc')
