from threading import Thread

def f():
    print ('thread function')
    return

if __name__ == '__main__':
    for i in range(3):
            t=Thread(target=f)
            t.start()
            
    print("From main")    
   
