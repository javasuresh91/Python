import threading

TOTAL = 0

class CountThread(threading.Thread):
    def run(self):
        global TOTAL
        for i in range(100000):
            TOTAL = TOTAL + 1
        print('%s\n' % (TOTAL))

a = CountThread()
b = CountThread()
a.start()
b.start()