
import threading
class AsyncCopy(threading.Thread):
    def __init__(self, infile, outfile):
        super().__init__()
        self.infile = infile
        self.outfile = outfile
    def run(self):
        print("Copying infile to outfile")
        
        

background = AsyncCopy('foo.txt', 'foo1.txt')
background.start()
print('The main program continues to run in foreground.')
background.join() # Wait for the background task to finish
print('Copying completed.')
