#Demo for return statement

total=10 #global scope

def findsum( arg1, arg2 ):
    # Add both the parameters and return them."
    global total
    total = total+arg1 + arg2
    print ("Inside the function : ", total)
    return total 

# Now you can call sum function
ret = findsum( 10, 20 )
print ("Outside the function : ", ret)
print ("Outside the function : ", total)



















'''
def change(b):
        b=b+20
        print(b)
     
b=10
change(b)
print(b)
'''
'''
Python passes references-to-objects by value (like Java), and everything in Python is an object. 
This sounds simple, but then you will notice that some data types seem to exhibit pass-by-value characteristics, while others seem to act like pass-by-reference... what's the deal?

It is important to understand mutable and immutable objects. Some objects, like strings, tuples, and numbers, 
are immutable. Altering them inside a function/method will create a new instance and the original instance outside the function/method is not changed. 
Other objects, like lists and dictionaries are mutable, which means you can change the object in-place. 
Therefore, altering an object inside a function/method will also change the original object outside.
'''
           
