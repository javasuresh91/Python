#Demo for return statement

total=3450

def findsum( arg1, arg2 ):
    # Add both the parameters and return them."
    
    total = total + arg2 + arg1
    print ("Inside the function : ", total) 
    return total;

# Now you can call sum function
res = findsum( 10, 20 ); 
print ("Outside the function : ", res)
print(total) 


