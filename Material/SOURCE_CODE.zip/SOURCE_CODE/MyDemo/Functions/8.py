

a=10   # Global
def test():
    '''Function test - adds 20 to the global variable'''
    global a   
    a=a+20
    print(a)


 
test()
print(a) 
print(test.__doc__)    #retrieving the docstring for the function
