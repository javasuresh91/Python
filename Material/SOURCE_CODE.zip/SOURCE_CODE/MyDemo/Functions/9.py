'''
Created on May 18, 2016

@author: DD0056362
'''
#immutable
def changeStr(s):
    s="new string"  
    print(s) 
    
    

s="old string"  
changeStr(s)
print(s)   



         
