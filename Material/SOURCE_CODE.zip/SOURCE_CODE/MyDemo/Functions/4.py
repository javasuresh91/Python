#Demo on variable length arguments - Method overloading in python

def  print_student_marks( name,  *student_marks):
    #print(type(student_marks))
    print(name)
    s=0
    for marks in student_marks:
        s=s+marks
    print(s)
   



#calling code

print_student_marks('Tom', 90,80,70,100,56,12)

print_student_marks('Jerry', 90, 88,12,34)

print_student_marks('Jack')



# same function name but different parameters - method overloading

