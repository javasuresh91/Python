#Demo on default arguments

def divide ( a, b=2):
    result=a//b
    return result



# function invocation

print(divide(10,5)) 

print(divide(10)) 
