
#Demo on Keyword arguments

def add ( x, y):
    result=x+y
    #print(result)
    return result

#function invocation using keywords

a=10
b=20

c=add(a,b)
print(c) #30


print(add(x=20,y=30))

print(add(y=10, x=20))


