#Simple function

def printme(a,b):
    print(a)

print(printme("Hello","World"))
printme("Hi","Welcome")

# printme([1,2,3])