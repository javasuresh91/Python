import pack1.calc as c

c.add(1,2)



