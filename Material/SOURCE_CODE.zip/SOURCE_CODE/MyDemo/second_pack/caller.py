'''
Created on Mar 17, 2016

@author: DD0056362
'''
from first_pack.m1 import fun


from second_pack.m1 import fun
fun()