'''
Created on Mar 17, 2016

@author: DD0056362
'''
def fun():
    print("Python is grea.....t")
    
    