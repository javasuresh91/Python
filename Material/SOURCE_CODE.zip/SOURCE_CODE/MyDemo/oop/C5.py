class Parent:        # define parent class
   def myMethod(self):
      print( 'Calling parent method')
      
   def __init__(self):
                print("constructor in parent")    

class Child(Parent): # define child class
   def myMethod(self,ab):
      Parent.myMethod(self)
      print( 'Calling child method')
      
   def __init__(self):
       print("constructor in child")   

c = Child()          # instance of child
c.myMethod(10)        # child calls overridden method
p=Parent()
p.myMethod()












'''
import pickle
f=open("test.txt","wb")
p=pickle.Pickler(f)
print(type(c))
p.dump(c)
f.close()

f=open("test.txt","rb")
p=pickle.Unpickler(f)
d=p.load()
d.myMethod()
'''
