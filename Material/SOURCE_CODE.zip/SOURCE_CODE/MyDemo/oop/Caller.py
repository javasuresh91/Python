'''
Created on Mar 3, 2016

@author: DD0056362
'''
from oop.C3 import Bag

bag=Bag()
bag.add(10)

from oop.Mod1 import met
met()







