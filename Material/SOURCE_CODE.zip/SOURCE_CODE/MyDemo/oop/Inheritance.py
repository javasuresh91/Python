'''
Created on Mar 10, 2016

@author: DD0056362
'''

class Shape:
    title="Class concerns with Shapes"#  Shape.title
    
    
    def Class_level_met():
        print("I am class level method from SHAPE")  # Shape.Class_level_met()
        
     #description
    def __init__(self,description,dimension,pvt):
        self.description=description
        self.dimension=dimension
        self.__pvt=pvt


    def display(self):
        print('from Shape')
        print("description is ",self.description)
        print("dimension is ",self.dimension)
        print("dimension is ",self.__pvt)
        print("title is ",Shape.title)



#description and dimension(from Parent),size(of its oqn)
#description - obviously
#colour and size        
class Square(Shape):

    def __init__(self,description,dimension,pvt,colour,size):
           Shape.__init__(self,description,dimension,pvt)   # 2 varibles get initialized for me
           #specific attributes

           self.colour=colour
           self.size=size
           
    #method overriding - changing the behavior of an already inherited method
    
    def display(self):
        #print('python is fun')
        Shape.display(self)
        print(self.colour)
        print(self.size)
        #print(self.__pvt) #not possible to access directly -- it is really inherited?
        print(self._Square__pvt)
    

    # subclass normal method

    def SqDisplay(self):
        print("Normal method from Square class")
     
 #-------------------------------------------------------------      


# object creations
'''
shape=Shape("It is a SHAPE",'2D') #description and dimension is initialized
shape.display() # Shape class's display method
Shape.Class_level_met()
'''

square=Square("It is a Square",'2D','private','red',10)
square.display() # which display will be called? Square class's version is called
square.SqDisplay()
Square.Class_level_met()











