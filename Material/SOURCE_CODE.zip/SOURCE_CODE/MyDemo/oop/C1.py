

class Employee:
   
    
    empCount = 0 # CLASS level attribute -independent of object
    
    #As a developer I have thought that each Employee should have 4 instance vars:
    # eid, name, salary, __grade
  
    #constructs --> which constructs --> an object
    def __init__(self,Eid, Name,Salary,Grade):
        
     print("Inside constructor")
     self.eid=Eid
     self.name = Name
     self.salary = Salary
     self.__grade=Grade # security purpose --> private member of the class
     Employee.empCount=Employee.empCount+1


    def classLevelMethod():     
      print("Total Employee %d" % Employee.empCount) # a class level variable is accsessed with Class Name
  

    def displayEmployee(self):
      
     print("Name : ", self.name,  ", Salary: ", self.salary,", grade: ", self.__grade)




#-----------------------------------------------------------------------------------------------

Employee.classLevelMethod() # I can call the class level method without any object creation


#creating 1st object
e1=Employee(1,"John",1000,"U1") # calls the constructor __init__
e1.displayEmployee()
print(e1.eid)
print(e1.name)
print(e1.salary)
print(e1._Employee__grade) #  name mangling by interpreter
#print(e1.__grade) #not allowed
Employee.classLevelMethod()
print(e1.__dict__)
print(getattr(e1,_Employee__grade))



#creating 2nd object
e2=Employee(2,"Dipika",2000,"U2") # calls the constructor __init__
e2.displayEmployee()
Employee.classLevelMethod()


# you can add specific attrs to an object which might not be in the class
e2.age=34
print(hasattr(e2,'age')) #true
print(e2.age) #34
delattr(e2,'age')
print(hasattr(e2,'age')) #false'




