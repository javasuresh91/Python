class Complex:
    def __init__(self, realpart, imagpart):
        self.r = realpart
        self.i = imagpart

    def __str__(self):
        return "Real = %d imag = %d "%(self.r,self.i)   
    
    def __add__(self,other):
        return Complex(self.r+other.r,self.i+other.i) 
    def disp(self):
        print(self.r,"+",self.i,"j")
        
        
        
x=Complex(1,2)
x.disp()

y=Complex(2,3)
y.disp()

x.__add__(y)
z=x+y



