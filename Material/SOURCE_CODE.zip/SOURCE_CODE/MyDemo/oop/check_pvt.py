class C:
    def __init__(self,x):
        self._x = x
'''
    def getx(self):
        return self._x

    def setx(self, value):
        self._x = value

    def delx(self):
        del self._x
'''
c = C(10)
print(c._C__x)
    
