class Parent:        # define parent class
   parentAttr = 100
   
   def __init__(self):
      print("Calling parent class's constructor")
      
   def met(self):
        print("A simple parent class method not overridden by child")      

   def parentMethod(self):
      print ('From parentMethod')

   def setAttr(self, attr):
      Parent.parentAttr = attr

   def getAttr(self):
      print ("Parent attribute :", Parent.parentAttr)


class Child(Parent): # define child class
    def __init__(self):
      Parent.__init__(self) # explicitely the Parent cons has to be called as the first line
      print ("Calling child constructor")
     
      
    def childMethod(self):
      print ('Calling childMethod')      
      
    def parentMethod(self):
      
      print ('Calling child method')
 
 
p=Parent()
p.parentMethod()
#p.childMethod()

       
c = Child()          # instance of child
c.childMethod() # which is present only in the Child class
c.parentMethod()     # calls parent's method
c.met()


print(issubclass(Child, Parent))

print(isinstance(c, Child))


# c.setAttr(200)       # again call parent's method
# c.getAttr()          # again call parent's method

