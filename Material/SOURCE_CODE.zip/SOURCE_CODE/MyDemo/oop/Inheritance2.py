'''
Created on May 10, 2016

@author: DD0056362
'''
class A:
    def met(self):
        print("from A")
        
class B:
    def met(self):
        print("from B")
        
        
class C(A,B):
       
    def met(self):
        B.met(self)      
        print("from C")
    


#------------

c=C()
c.met()

            
            
    
