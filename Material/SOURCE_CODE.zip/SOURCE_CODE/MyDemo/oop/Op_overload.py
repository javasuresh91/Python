class Vector:
    def __init__(self, a, b):
        self.a = a
        self.b = b
        
    
    def __str__(self):
        return 'My Vector now becomes ***** (%d, %d)' % (self.a, self.b)
        
    
    def __add__(self,otherVector):
        a=self.a+otherVector.a
        b=self.b+otherVector.b
        v=Vector(a,b)
        return v


v1 = Vector(2,10)
v2 = Vector(5,-2)
v3 = Vector(5,-2)
v4 = Vector(5,-2)
v5 = Vector(5,-2)
v6 = Vector(5,-2)
v7 = Vector(5,-2)

vnew=v1+v2+v3+v4+v5+v6+v7

print(vnew)
































    
    

    
