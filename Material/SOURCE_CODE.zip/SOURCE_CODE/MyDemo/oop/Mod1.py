'''
Created on Mar 11, 2016

@author: DD0056362
'''
def met():
    print("From Mod1's met()")