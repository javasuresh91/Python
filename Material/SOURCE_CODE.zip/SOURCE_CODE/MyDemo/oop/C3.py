class Bag:
        data=10   # class var     Bag.data
        def __init__(self):
            self.data = []    # instance var  self.data
        def add(self, data):
            self.data.append(data)
        def addtwice(self, x):
            self.add(x)
            self.add(x)

b=Bag()
b.addtwice(2)
b.addtwice(4)
b.add(5)
print(b.data)
print(Bag.data)


