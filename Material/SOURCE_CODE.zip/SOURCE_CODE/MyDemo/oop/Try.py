'''
Created on May 19, 2016

@author: DD0056362
'''
class Try:
    def initiate(self,a,b):
        self.a=a
        self.b=b
        
        
o=Try()
o.initiate(12, 13)
print(o.a)        
        