'''
Created on Mar 3, 2016

@author: DD0056362

Constructor Overloading
'''
class Test:
    def __init__(self,*attributes):             
        print("inside init")
        
        if len(attributes)==0:
            print("No instance variable in the class")
            
        if len(attributes)==1:
            self.firstAtt=attributes[0]
            
        if len(attributes)==2:
            self.firstAtt=attributes[0]
            self.secondAtt=attributes[1]


t1=Test() # no instance variable


t2=Test(1) # firstAtt
print(t2.firstAtt)



t3=Test(1,3) # firstAtt = 1 secondAtt=3
print(t3.firstAtt)
print(t3.secondAtt)

        
        
        
