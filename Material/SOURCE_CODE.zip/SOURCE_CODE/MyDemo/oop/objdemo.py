class vehicle:
    type="light weight"
    #class variable - common for the class and not specific to an obj
    def __init__(self,*arg):    #Constructor - to initialize the object
        print("Constructor called with ",len(arg)," params") 
        
        if len(arg)==3:
            self.gear=arg[0] 
            self.model=arg[1]
            self.name=arg[2]
            #elf.gear,self.model,self.name=arg
        elif len(arg)==2:
            self.gear=arg[0]
            self.model=arg[1]
        elif len(arg)==1:
            self.gear=arg[0]
        else:
            print("Its a sportbike")
    def start(self):
        #another instance variable
        self.engine="H123"
        print("Engine started")

    def printdetails(self):
        print(self.model,self.name,self.gear,self.engine,vehicle.type)

       
car=vehicle(6,"Audi 2013","Audi") # car is an instance of vehicle - car is an object

car.start()
car.printdetails()
print(car.name)

car2=vehicle(1,"Nissan")
print(car2.gear)
print(car2.name)

car3=vehicle()





