class B(Exception):
    
        pass
class C(B):
        pass
class D(C):
        pass

for c in [B, C, D]:
        try:
            
            raise(c)
            pass
        
        
        except D:
            print("D")
        except C:
            print("C")
        except B:
            print("B")