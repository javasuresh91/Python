'''
Created on May 19, 2016

@author: DD0056362
'''
class ToString:
    
    def __init__(self,a,b):
        self.a=a
        self.b=b
        
    
    def __str__(self):
        return "a = %d b = %d "%(self.a,self.b)

    def display(self):
        print(self.a)
        
        
obj=ToString(10,20)
#print(obj) 
#print(obj.__str__)
print(str(obj))
