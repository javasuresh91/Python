
import re


str = ' This is a word:and example word:dog!!'

search = re.match(r'word:\w\w\w', str)
# If-statement after search() tests if it succeeded
if search:                      
    print('found', search.group()) 
else:
    print('did not find')




# match --- > matches a pattern only at the beginning of string
# search --> can search anywhere in the string and returns the first occ
