import re

str = 'abc abc abc shsdfhdfkhfdkfh purple alice@google.com, blah monkey bob@abc.com blah blah blah'

  
emails = re.findall(r'[\w\.-]+@[\w\.-]+', str) 
for email in emails:
    # do something with each found email string
    print (email)
