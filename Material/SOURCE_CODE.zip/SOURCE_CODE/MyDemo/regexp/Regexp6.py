import re
str = 'purple alice@google.com, blah monkey bob@abc.com blah blah blah'

print (re.sub(r'([\w\.-]+)@[\w\.-]+', r'\1@gmail.com', str))

#print(str)

