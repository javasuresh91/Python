import re


str = '<b>foo</b> and <i>so on</i>'

match = re.search('<.*>', str)     
if match:
    print (match.group())

  

match = re.search('(<.?>)', str)     
if match:
    print (match.group())


