import re
f=open("input.txt",'r')
s=f.read()
segment_list=s.split("<Sep 6")

for i in range(0,len(segment_list)):
    print('segment no : '+str(i))
    x='<Sep 6'+segment_list[i]
    print(x)
   
    

  







'''
str = 'purple alice-b@google.com monkey dishwasher'
match = re.search(r'\w+-.@\w+\.\w+', str)
if match:
        print (match.group())  
else:
        print("not found")



str = 'purple alice-b@google.com monkey dishwasher'
match = re.search(r'([\w.-]+)@[\w\.]+', str)
if match:
     print (match.group())   ## 
     print (match.group(1))  ## 
     #print (match.group(2))  ## 

'''
