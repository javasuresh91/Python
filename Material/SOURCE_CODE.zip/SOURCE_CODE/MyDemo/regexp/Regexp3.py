import re
#from file
#f=open("foo.txt")
#print(re.findall(r'[\w.-]+@[\w.-]+', f.read()))



str = 'purple alice-b@google.com monkey dishwasher'
match = re.search(r'\w+-.@\w+\.\w+', str)
if match:
        print (match.group())  
else:
        print("not found")



str = 'purple alice-b@google.com monkey dishwasher'
match = re.search(r'([\w.-]+)@([\w\.]+)', str)
if match:
     print (match.group())   ## 
     print (match.group(1))  ## 
     print (match.group(2))  ## 

