import re

match = re.search(r'pi*?', 'piiiiiiiiiiiiig') 
print(match.group())

match = re.search(r'i+?', 'piigiiii') 
print(match.group())


match = re.search(r'\d\s+\d\s+\d', 'xx123xx4 5   6tt')
print(match.group())


match = re.search(r'\d\s*\d\s*\d', 'xx12  3xx') 
print(match.group())


match = re.search(r'\d\s*\d\s*\d', 'xx123xx') 
print(match.group())



match = re.search(r'^f\w+', 'foobar') 
if match:
    print(match.group())
else:
    print("No match")

  

match = re.search(r'b\w+', 'foobar')
print(match.group())











