'''
Created on Mar 14, 2016

@author: DD0056362
'''
import re

## i+ = one or more i's, as many as possible.
match = re.search(r'pi+', 'piiig') # =>  found, match.group() == "piii"
print(match.group())


match = re.search(r'^f\w+', 'foobar') # =>  not found, match == None
if match:
    print(match.group())
else:
    print("No match")