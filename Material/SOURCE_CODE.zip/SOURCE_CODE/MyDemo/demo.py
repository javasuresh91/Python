

age=20

if(age>18):
        print('I am an adult')
        print(age)
else:
                    print('I am still achild')
                    print(age)

print('always executed')    
    
